<?php
$con=mysqli_connect("localhost","edequa5_mood25","85ySl7ojbP","edequa5_mood25");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
// report 5
$result = mysqli_query($con,"SELECT u.id, u.firstname, u.lastname, a.roleid, ue.courses, ff.videos, l1.urls, l0.evideos, l2.assignments, l3.quizes, l4.forums, l5.attendances
			FROM mdl_user u
				LEFT JOIN mdl_role_assignments a ON a.userid = u.id
				LEFT JOIN (SELECT ue.userid, count(e.courseid) as courses FROM mdl_role_assignments ra, mdl_user_enrolments ue, mdl_enrol e, mdl_context cxt WHERE e.id = ue.enrolid AND cxt.instanceid = e.courseid AND ra.contextid = cxt.id AND ra.userid = ue.userid AND (ra.roleid = 3 OR ra.roleid = 4) GROUP BY ue.userid) as ue ON ue.userid = u.id
				LEFT JOIN (SELECT f.userid, count(distinct(f.filename)) videos FROM mdl_files f WHERE f.mimetype LIKE '%video%' GROUP BY f.userid) as ff ON ff.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) urls FROM mdl_log l WHERE l.module = 'url' AND l.action = 'add' GROUP BY l.userid) as l1 ON l1.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) evideos FROM mdl_log l WHERE l.module = 'page' AND l.action = 'add' GROUP BY l.userid) as l0 ON l0.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) assignments FROM mdl_log l WHERE l.module = 'assignment' AND l.action = 'add' GROUP BY l.userid) as l2 ON l2.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) quizes FROM mdl_log l WHERE l.module = 'quiz' AND l.action = 'add' GROUP BY l.userid) as l3 ON l3.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) forums FROM mdl_log l WHERE l.module = 'forum' AND l.action = 'add' GROUP BY l.userid) as l4 ON l4.userid = u.id
				LEFT JOIN (SELECT l.userid, count(l.id) attendances FROM mdl_log l WHERE l.module = 'attendance' AND l.action = 'add' GROUP BY l.userid) as l5 ON l5.userid = u.id
				WHERE (a.roleid = 3 OR a.roleid = 4) GROUP BY u.id");

				


while($row = mysqli_fetch_array($result))
  {
    echo "NAME :{$row['firstname']}  <br> ".
         "Number of courses : {$row['courses']} <br> ".
         "Video files uploaded : {$row['videos']} <br> ".
		 "Quizzes : {$row['quizes']} <br> ".
		
         "--------------------------------<br>";
		 
}

<form name="myform" method="get">


    while($row = mysqli_fetch_array($result))
    {
      echo "<option value='" . $row['firstname'] . "'>" . $row['videos'] . "</option>";
    }

 
</form>



mysqli_close($con);
?>