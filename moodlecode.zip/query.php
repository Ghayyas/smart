<?php
$username = "edequa5_mood25";
$password = "85ySl7ojbP";
$hostname = "localhost"; 

//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password) 
  or die("Unable to connect to MySQL");
echo "Connected to MySQL<br>";

//select a database to work with
$selected = mysql_select_db("edequa5_mood25",$dbhandle) 
  or die("Could not select edequa5_mood25");

//execute the SQL query and return records
$result = mysql_query("SELECT gg.id, ccc.cohorts, cmc.completionstate, iq.name as iqname, isc.name as isname, DATE_FORMAT( FROM_UNIXTIME(gg.timemodified) , '%d-%m-%Y %H:%i:%s' ) AS completion_date, cm.id as cmid, cm.instance, cm.completion, c.fullname, u.id AS uid, u.firstname, u.lastname, u.email, m.name AS module_name, ROUND(gg.finalgrade, 0) AS finalgrade, DATE_FORMAT( FROM_UNIXTIME(gg.timecreated), '%d-%m-%Y at %h:%i' ) AS start_time
						FROM mdl_course_modules cm

							LEFT JOIN mdl_grade_items gi ON gi.iteminstance = cm.instance
							LEFT JOIN mdl_grade_grades gg ON gg.itemid = gi.id
							LEFT JOIN mdl_user as u ON u.id = gg.userid
							LEFT JOIN mdl_modules m ON m.id = cm.module
							LEFT JOIN mdl_course as c ON c.id=cm.course
							LEFT JOIN mdl_quiz as iq ON iq.id = cm.instance
							LEFT JOIN mdl_scorm as isc ON isc.id = cm.instance
							LEFT JOIN mdl_course_modules_completion as cmc ON cmc.coursemoduleid = cm.id AND cmc.userid = u.id
							LEFT JOIN (SELECT userid, GROUP_CONCAT( CAST( cc.cohortid AS CHAR )) AS cohorts FROM mdl_cohort_members cc GROUP BY cc.userid  ) ccc ON ccc.userid = u.id
								WHERE (m.name = 'quiz' OR m.name = 'scorm') AND gg.timecreated
ORDER BY gg.timecreated DESC");
//fetch tha data from the database
echo 'Student Name: '$fullname'';

while ($row = mysql_fetch_array($result)) {
   echo "ID:".$row{'fullname'}." Name:".$row{'iqname'}." 
   ".$row{'finalgrade'}."<br>";
}

?>