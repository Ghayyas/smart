<?php
$con=mysqli_connect("localhost","edequa5_mood25","85ySl7ojbP","edequa5_mood25");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
echo '<h1>Module Completion Report</h1></br></br>';

$result = mysqli_query($con,"SELECT gg.id, ccc.cohorts, cmc.completionstate, iq.name as iqname, isc.name as isname, gg.timemodified as completion_date, cm.id as cmid, cm.instance, cm.completion, c.fullname, u.id AS uid, u.firstname, u.lastname, u.email, m.name AS module_name, gg.finalgrade, gg.timecreated as start_time
						FROM prefix_course_modules cm
							LEFT JOIN prefix_grade_items gi ON gi.iteminstance = cm.instance
							LEFT JOIN prefix_grade_grades gg ON gg.itemid = gi.id
							LEFT JOIN prefix_user as u ON u.id = gg.userid
							LEFT JOIN prefix_modules m ON m.id = cm.module
							LEFT JOIN prefix_course as c ON c.id=cm.course
							LEFT JOIN prefix_quiz as iq ON iq.id = cm.instance
							LEFT JOIN prefix_scorm as isc ON isc.id = cm.instance
							LEFT JOIN prefix_course_modules_completion as cmc ON cmc.coursemoduleid = cm.id AND cmc.userid = u.id
							LEFT JOIN (SELECT userid, GROUP_CONCAT( CAST( cc.cohortid AS CHAR )) AS cohorts FROM prefix_cohort_members cc GROUP BY cc.userid) ccc ON ccc.userid = u.id
								WHERE (m.name = 'quiz' OR m.name = 'scorm') AND gg.timecreated GROUP BY gg.id");
								
while($row = mysqli_fetch_array($result))
  {
    echo "Student Name :{$row['firstname']}  <br> ".
         "Module Name : {$row['iqname']} <br> ".
		 "Course Name : {$row['fullname']} <br> ".
		 "Score : {$row['finalgrade']} <br> ".
		 "Time Completed (Actual) : {$row['start_time']} <br> ".
         "--------------------------------<br>";
} 
mysqli_close($con);
?>