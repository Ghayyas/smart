<?php
$con=mysqli_connect("localhost","edequa5_mood25","85ySl7ojbP","edequa5_mood25");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
// report 1
$result = mysqli_query($con,"SELECT ue.id, ccc.cohorts, ci.id as compl_enabled, ue.timecreated as enrolled, gc.avarage, cc.timecompleted as complete, u.id as uid, u.firstname, u.lastname, u.email, c.id as cid, c.fullname as course, c.timemodified as start_date 
						FROM mdl_user_enrolments as ue
							LEFT JOIN mdl_user as u ON u.id = ue.userid
							LEFT JOIN mdl_enrol as e ON e.id = ue.enrolid
							LEFT JOIN mdl_course as c ON c.id = e.courseid
							LEFT JOIN mdl_course_completions as cc ON cc.course = e.courseid
							LEFT JOIN (SELECT * FROM mdl_course_completion_criteria WHERE id > 0 GROUP BY course) as ci ON ci.course = e.courseid
							LEFT JOIN (SELECT gi.courseid, g.userid, AVG( (g.finalgrade/g.rawgrademax)*100 ) AS avarage FROM mdl_grade_items gi, mdl_grade_grades g WHERE gi.itemname != '' AND g.itemid = gi.id AND g.finalgrade IS NOT NULL GROUP BY gi.courseid, g.userid) as gc ON gc.courseid = c.id AND gc.userid = u.id
							LEFT JOIN (SELECT userid, GROUP_CONCAT( CAST( cc.cohortid AS CHAR )) AS cohorts FROM mdl_cohort_members cc GROUP BY cc.userid) ccc ON ccc.userid = u.id
								WHERE u.id > 0 AND ue.timecreated GROUP BY ue.userid, e.courseid");

while($row = mysqli_fetch_array($result))
  {
    echo "NAME :{$row['firstname']}  <br> ".
         "Course Name : {$row['course']} <br> ".
         "GRADE : {$row['avarage']} <br> ".
		// date("M d, Y",strtotime($row['enrolled'])),
		 "Time : {$row['enrolled']} <br> ".
         "--------------------------------<br>";
} 

mysqli_close($con);
?>
 
