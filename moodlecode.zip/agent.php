<?php
require_once(dirname(__FILE__) . '/config.php');
require_once($CFG->libdir . '/filelib.php');
require_once($CFG->dirroot . '/repository/lib.php');
require_once($CFG->dirroot . '/backup/util/includes/restore_includes.php');
require_once($CFG->dirroot . '/backup/restorefile_form.php');

error_reporting(E_ALL);
ini_set('display_errors', '1');

$contextid = optional_param('contextid', 0,  PARAM_INT);
$upload = optional_param('upload', 0,  PARAM_INT);
$backupfile = optional_param('backupfile', '', PARAM_RAW);
$filename = optional_param('filename', '', PARAM_RAW);
$filepath = optional_param('filepath', '', PARAM_RAW);
$stage       = optional_param('stage', restore_ui::STAGE_CONFIRM, PARAM_INT);
$username = optional_param('username', '', PARAM_RAW);
$password = optional_param('password', '', PARAM_RAW);
$file = optional_param('file', '', PARAM_RAW);

print('<style>body{margin: 0;} div,p,table, form{display:none;}li{ background-color: #ddd; color: #666666;display: block;font: 12px Verdana;padding: 10px 20px;}</style>');
if($username and $password){
	$PAGE->https_required();
	$context = context_system::instance();
	$PAGE->set_context($context);
	$authsequence = get_enabled_auth_plugins(true); // auths, in sequence
	foreach($authsequence as $authname) {
		$authplugin = get_auth_plugin($authname);
		$authplugin->loginpage_hook();
	}

	$restore_url = new moodle_url('agent.php', array('file'=> $file));
	if($USER->id > 1){
		print("<li class='note'>$username already authenticated</li>");
		redirect($restore_url);
	}elseif($user = authenticate_user_login($username, $password)){
		 update_login_count();
		 complete_user_login($user);
		 set_moodle_cookie($user->username);
		print("<li class='note'>Authenticate user... Hello $user->email</li>");
		redirect($restore_url);
	}else{
		die("<li class='note'>Unknown user - $username</li>");
	}
}


if($file){
	$context = context_system::instance();
	list($context, $course, $cm) = get_context_info_array($context->id);

	$tmpdir = $CFG->tempdir . '/backup';
	$filename = restore_controller::get_tempdir_name($course->id, $USER->id);
    $pathname = $tmpdir . '/' . $filename;
	$file = file_get_contents($file);
	file_put_contents($pathname, $file);
	$restore_url = new moodle_url('agent.php', array('contextid'=>$context->id, 'filename'=> $filename));
    redirect($restore_url);
}

if($contextid){
	list($context, $course, $cm) = get_context_info_array($contextid);
	$PAGE->set_context($context);
	if ($stage & restore_ui::STAGE_CONFIRM + restore_ui::STAGE_DESTINATION) {
		$restore = restore_ui::engage_independent_stage($stage, $contextid);
	} else {
		$restoreid = optional_param('restore', false, PARAM_ALPHANUM);
		$rc = restore_ui::load_controller($restoreid);
		if (!$rc) {
			$restore = restore_ui::engage_independent_stage($stage/2, $contextid);
			if ($restore->process()) {
				$rc = new restore_controller($restore->get_filepath(), $restore->get_course_id(), backup::INTERACTIVE_YES,
									backup::MODE_GENERAL, $USER->id, $restore->get_target());
			}
		}
		if ($rc) {
			if ($rc->get_status() == backup::STATUS_REQUIRE_CONV) {
				$rc->convert();
			}

			$restore = new restore_ui($rc, array('contextid'=>$context->id));
		}
	}

	$outcome = $restore->process();
	if (!$restore->is_independent()) {
		if ($restore->get_stage() == restore_ui::STAGE_PROCESS && !$restore->requires_substage()) {
			try {
				$restore->execute();
			} catch(Exception $e) {
				$restore->cleanup();
				throw $e;
			}
		} else {
			$restore->save_controller();
		}
	}
	$renderer = $PAGE->get_renderer('core','backup');
	$html = $restore->display($renderer);
	echo str_replace('backup/restore','agent',$html);
	$restore->destroy();
	unset($restore);
	

	if($stage == 1){
		print("<li style='width:40%;' class='note'>Checking a Backup...</li>");
		die('<script>document.getElementsByTagName("form")[0].submit();</script>');
	}
	if($stage == 2){
		print("<li style='width:55%;' class='note'>Configure Settings...</li>");
		die('<script>
			var targets = document.getElementsByName("targetid");
			for(var i = 0; i < targets.length; i++){
				targets[i].checked = true;
				break;
			}
			document.getElementsByTagName("form")[0].submit();
		</script>');
	}
	if($stage == 4){
		print("<li style='width:60%;' class='note'>Prepare to import...</li>");
		die('<script>document.getElementsByTagName("form")[0].submit();</script>');
	}
	if($stage == 8){
		print("<li style='width:75%;' class='note'>Import Processing...</li>");
		die('<script>document.getElementById("id_submitbutton").click();</script>');
	}
	if($stage < 16){
		print($stage."<li style='width:80%;' class='note'>Finishing import...</li>");
		die('<script>//document.getElementsByTagName("form")[0].submit();</script>');
	}
}
die("<script>parent.closedialog();</script> <li class='note'>Done.</li>");

